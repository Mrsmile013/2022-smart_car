#ifndef _wwdg_h_
#define _wwdg_h_
#include "headfile.h"


extern uint8 WWDG_Flag;


void WWDG_init(void);
void Wwdg_irq_ON(void);
void Wwdg_reset_ON(u8 ucTcnt, u8 ucWcnt);



















#endif
