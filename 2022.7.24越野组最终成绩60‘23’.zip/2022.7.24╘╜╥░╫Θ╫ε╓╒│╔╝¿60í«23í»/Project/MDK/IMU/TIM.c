#include "TIM.h"
#include "headfile.h"
#include "stdlib.h"
#include "math.h"

uint32 cnt_1ms = 0;

uint32 speed_counter=0;

uint8 FLAG_1MS = false;
uint8 FLAG_5MS = false;
uint8 FLAG_10MS = false;
uint8 FLAG_40MS = false;
uint8 FLAG_60MS = false;
uint8 FLAG_100MS = false;
uint8 FLAG_500MS = false;
uint8 FLAG_1000MS = false;
uint8 FLAG_5000MS = false;


void time_isr(void)
{
	cnt_1ms++;
	if (cnt_1ms%1 == 0 && cnt_1ms!=0)	 FLAG_1MS = true;
	if (cnt_1ms%5 == 0 && cnt_1ms!=0)	 FLAG_5MS = true;
	if (cnt_1ms%10 == 0 && cnt_1ms!=0)	 FLAG_10MS = true;
	if (cnt_1ms%40 == 0 && cnt_1ms!=0)	 FLAG_40MS = true;
	if (cnt_1ms%60 == 0 && cnt_1ms!=0)	 FLAG_60MS = true;
	if (cnt_1ms%100 == 0 && cnt_1ms!=0)	 FLAG_100MS = true;
	if (cnt_1ms%500 == 0 && cnt_1ms!=0)	 FLAG_500MS = true;
	if (cnt_1ms%1000 == 0 && cnt_1ms!=0) FLAG_1000MS = true;
	if (cnt_1ms%5000 == 0 && cnt_1ms!=0) FLAG_5000MS = true;
	if (cnt_1ms > 5000) cnt_1ms = 0;
}

void get_speed(void)
{
	if(FLAG_10MS==true)
	{
		FLAG_10MS=false;
		speed_counter += abs(tim_encoder_get_count(ENCODER1_TIM));		
	}
	if(FLAG_1000MS==true)
	{
		FLAG_1000MS=false;
		tim_encoder_rst(ENCODER1_TIM);
		printf("%ld\r\n",speed_counter);
		speed_counter=0;
	}
}

void TIM6_IRQHandler (void)
{
	uint32 state = TIM6->SR;														// ��ȡ�ж�״̬
	TIM6->SR &= ~state;																// ����ж�״̬
	time_isr();
}




















