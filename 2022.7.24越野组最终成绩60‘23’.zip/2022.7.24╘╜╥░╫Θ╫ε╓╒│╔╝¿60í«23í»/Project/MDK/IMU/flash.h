#ifndef __FLASH_H__
#define __FLASH_H__
#include "headfile.h"

#define SECTION_INDEX		FLASH_SECTION_127										// 最后一个扇区
#define PAGE_INDEX			FLASH_PAGE_3											// 最后一个页

unsigned long ex_float2int(float value);       //浮点型转换为长整型
float ex_int2float(unsigned long value);       //长整型转换为浮点型
void takeoff_two_numb(uint32 data_buffer[],float gps_point[]);
void take_in_numb(uint32 data_buffer[], float gps_point[]);


#endif
