#ifndef _JY901B_H_
#define _JY901B_H_

typedef struct 
{
	short a[3];
	short T;
}SAcc;
typedef struct 
{
	short w[3];
	short T;
}SGyro;
typedef struct 
{
	short Angle[3];
	short T;
}SAngle;

typedef struct 
{
	float date[3];
	
}IMU;




extern IMU 		JY901ACC;   // ���ٶ�
extern IMU 		JY901GYRO;	// ���ٶ�
extern IMU 	JY901Angle;		//�Ƕ�


void JY901B(void);

void JY901B_getdate(void);

float Yaw_0pian(float Yaw);


#endif /* Includes */



