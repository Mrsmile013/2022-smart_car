#ifndef __ESP_H__
#define __ESP_H__	 
#include "common.h"

#define WIRELESS_UART			UART_4												// ����ת����ģ�� ��ʹ�õ��Ĵ���
#define WIRELESS_UART_TX		UART4_TX_C10
#define WIRELESS_UART_RX		UART4_RX_C11
#define WIRELESS_UART_BAUD		115200


void esp8266_connext(void);


void Delay1ms(unsigned int y);

void esp_flag(void);

void get_date(void);

void esp8266_printf(void);

#endif





